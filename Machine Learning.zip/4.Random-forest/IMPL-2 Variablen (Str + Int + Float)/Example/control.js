var data = [
    {class: '1st', name: 'Allen, Miss. Elisabeth Walton', sex: 'female', age: 29, sibsp: 0, parch: 0, ticket: '24160', fare: 211.3375, cabin: 'B5', survived: 'yes'},
    {class: '3rd', name: 'Andersson, Mr. Anders Johan', sex: 'male', age: 39, sibsp: 1, parch: 5, ticket: '347082', fare: 31.275, cabin: '', survived: 'no'},
    {class: '1st', name: 'Andrews, Miss. Kornelia Theodosia', sex: 'female', age: 63, sibsp: 1, parch: 0, ticket: '13502', fare: 77.9583, cabin: 'D7', survived: 'yes'},
    {class: '3rd', name: 'Asplund, Master. Edvin Rojj Felix', sex: 'male', age: 3, sibsp: 4, parch: 2, ticket: '347077', fare: 9.3875, cabin: '', survived: 'yes'},
    {class: '1st', name: 'Astor, Col. John Jacob', sex: 'male', age: 47, sibsp: 1, parch: 0, ticket: 'PC 17757', fare: 227.525, cabin: 'C62 C64', survived: 'no'},
    {class: '2nd', name: 'Beane, Mr. Edward', sex: 'male', age: 32, sibsp: 1, parch: 0, ticket: '2908', fare: 26, cabin: '', survived: 'yes'},
    {class: '2nd', name: 'Becker, Master. Richard F', sex: 'male', age: 1, sibsp: 2, parch: 1, ticket: '230136', fare: 39, cabin: 'F4', survived: 'yes'},
    {class: '3rd', name: 'Bengtsson, Mr. John Viktor', sex: 'male', age: 26, sibsp: 0, parch: 0, ticket: '347068', fare: 7.775, cabin: '', survived: 'no'},
    {class: '1st', name: 'Bishop, Mr. Dickinson H', sex: 'male', age: 25, sibsp: 1, parch: 0, ticket: '11967', fare: 91.0792, cabin: 'B49', survived: 'yes'},
    {class: '3rd', name: 'Boulos, Mrs. Joseph (Sultana)', sex: 'female', age: 40, sibsp: 0, parch: 2, ticket: '2678', fare: 15.2458, cabin: '', survived: 'no'},
    {class: '1st', name: 'Bowen, Miss. Grace Scott', sex: 'female', age: 45, sibsp: 0, parch: 0, ticket: 'PC 17608', fare: 262.375, cabin: 'A23', survived: 'yes'},
    {class: '3rd', name: 'Brocklebank, Mr. William Alfred', sex: 'male', age: 35, sibsp: 0, parch: 0, ticket: '364512', fare: 8.05, cabin: '', survived: 'no'},
    {class: '2nd', name: 'Brown, Miss. Edith Eileen', sex: 'female', age: 15, sibsp: 0, parch: 2, ticket: '29750', fare: 39, cabin: '', survived: 'yes'},
    {class: '3rd', name: 'Cacic, Miss. Manda', sex: 'female', age: 21, sibsp: 0, parch: 0, ticket: '315087', fare: 8.6625, cabin: '', survived: 'no'},
    {class: '1st', name: 'Cardeza, Mr. Thomas Drake Martinez', sex: 'male', age: 36, sibsp: 0, parch: 1, ticket: 'PC 17755', fare: 512.3292, cabin: 'B51', survived: 'yes'},
    ];
  
  // Configuration adapted for the Titanic dataset
  var config = {
      trainingSet: data, 
      categoryAttr: 'survived', // Assuming we want to predict survival
      ignoredAttributes: ['person', 'name', 'ticket', 'cabin'] // Ignoring non-numeric and unique identifiers
  };
  
  // Building Random Forest
  var numberOfTrees = 3;
  var randomForest = new dt.RandomForest(config, numberOfTrees);
  
  // Sample test data from the Titanic dataset
  var samplePassenger = {
    class: '2nd', 
    name: 'Brown, Miss. Edith Eileen', 
    sex: 'female', 
    age: 15, 
    sibsp: 0, 
    parch: 2, 
    ticket: '29750', 
    fare: 39, 
    cabin: ''
  };
  
  // Predictions for the sample test data
  var randomForestPrediction = randomForest.predict(samplePassenger);
  
  // Displaying predictions
  document.getElementById('testingItem').innerHTML = JSON.stringify(samplePassenger, null, 0);
  document.getElementById('randomForestPrediction').innerHTML = JSON.stringify(randomForestPrediction, null, 0);
